#ifndef _HEADERS_H_
#define _HEADERS_H_

#include <stdint.h>
#include <iostream>
#include <thread>   
#include <functional>
#include <vector>   
#include <queue>       
#include <chrono>  
#include <string>
#include <time.h> 
#include <mutex> 

using namespace std;

#endif //_HEADERS_H_